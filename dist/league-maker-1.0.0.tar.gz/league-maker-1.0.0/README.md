## HI! This is a python library for football lovers!

### This Library is a small one and pretty simple

## Enjoy!!

This code is published on <a href="https://github.com/king-tomi/league">Github</a>